Command line used to find this crash:

/fuzzer/afl++/afl-fuzz -i /seeds/unibench/general_evaluation/jpg -o /home/autofz/output/exiv2/lafintel -m none -t 1000+ -M afl-master_1 -- /d/p/lafintel/unibench/exiv2/exiv2 @@

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 0 B.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please post
to https://github.com/AFLplusplus/AFLplusplus/issues/286 once the issues
 are fixed :)

